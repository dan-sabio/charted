# Thank you for your contributions!

Before opening a pull request please make sure that
`npm test` passes and that your style is somewhat
similar to ours.
